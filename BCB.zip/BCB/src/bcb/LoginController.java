/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bcb;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class LoginController implements Initializable {

    @FXML
    private Label label1;
    @FXML
    private TextField textUsername;
    @FXML
    private PasswordField textPassword;
    @FXML
    private Button loginButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleButton(ActionEvent event) throws IOException {
        if(event.getSource()==loginButton){
            String username=textUsername.getText();
            String password=textPassword.getText();
            if(username.equalsIgnoreCase("Admin")&&password.equalsIgnoreCase("Admin")){
                 System.out.println("Login Succesfull");
                 Stage primaryStage=new Stage();
                  Parent root=FXMLLoader.load(getClass().getResource("President.fxml" ));
                  Scene scene=new Scene(root);
                  primaryStage.setScene(scene);
                  primaryStage.show();
               
            }
            else{
                System.out.println("Username/Password combination not found");
            }
        }
    }
    
}
